//
//  WSLWaterLoadingView.m
//  水波型进度条
//
//  Created by 王双龙 on 16/10/7.
//  Copyright © 2016年 http://www.jianshu.com/users/e15d1f644bea All rights reserved.
//

#import "WSLWaterLoadingView.h"

@implementation WSLWaterLoadingView{
    CAShapeLayer *_layer;
    CADisplayLink *_link;
    CGFloat _waveWidth;
    CGFloat _offset,_h;
    CAShapeLayer *_layer2;
}

//初始化
- (instancetype)initWithFrame:(CGRect)frame font:(UIFont *)titleFont viewStyle:(ViewStyle)style{
    if (self = [super initWithFrame:frame]) {
        //CGRect rect = [title boundingRectWithSize:CGSizeMake(MAXFLOAT, 100) options:NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName : [UIFont boldSystemFontOfSize:40]} context:nil];
        CGRect rect = frame;
        CGFloat w = rect.size.width;
        
        _crossLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rect.size.width, rect.size.height)];
        _crossLabel.textColor = [UIColor redColor];
        _crossLabel.font = titleFont;
        _crossLabel.adjustsFontSizeToFitWidth = YES;
       // _crossLabel.backgroundColor = [UIColor colorWithRed:0.24 green:0.61 blue:0.91 alpha:0.9];
        _crossLabel.backgroundColor = [UIColor greenColor];
        _crossLabel.textAlignment = NSTextAlignmentCenter;
        _crossLabel.clipsToBounds = YES;
        _crossLabel.layer.cornerRadius = w/2;
        
        _bottomLabel = [[UILabel alloc] initWithFrame:_crossLabel.frame];
        _bottomLabel.textColor = [UIColor whiteColor];
        _bottomLabel.font = titleFont;
        _bottomLabel.adjustsFontSizeToFitWidth = YES;
        _bottomLabel.backgroundColor = [UIColor colorWithRed:0.24 green:0.61 blue:0.91 alpha:1.00];
        _bottomLabel.textAlignment = NSTextAlignmentCenter;
        _bottomLabel.clipsToBounds = YES;
        _bottomLabel.layer.cornerRadius = w/2;
        
        _topLabel = [[UILabel alloc] initWithFrame:_crossLabel.frame];
        _topLabel.textColor = [UIColor colorWithRed:0.24 green:0.61 blue:0.91 alpha:1.00];
        _topLabel.font = titleFont;
        _topLabel.adjustsFontSizeToFitWidth = YES;
        _topLabel.backgroundColor = [UIColor greenColor];
        _topLabel.textAlignment = NSTextAlignmentCenter;
        _topLabel.clipsToBounds = YES;
        _topLabel.layer.cornerRadius = w/2;
        
        [self addSubview:_crossLabel];
        [self addSubview:_topLabel];
        [self addSubview:_bottomLabel];
        
        //贝塞尔曲线
        UIBezierPath *path = [UIBezierPath bezierPath];
        [path moveToPoint:CGPointMake(0, rect.size.height/2)];
        [path addLineToPoint:CGPointMake(rect.size.width, rect.size.height/2)];
        [path addLineToPoint:CGPointMake(rect.size.width, rect.size.height)];
        [path addLineToPoint:CGPointMake(0, rect.size.height)];
        [path closePath];
        
        _layer = [CAShapeLayer layer];
        _layer.frame = _topLabel.bounds;
        //layer.backgroundColor = [UIColor blackColor].CGColor;
        _layer.path = path.CGPath;
        _layer.strokeColor = [UIColor clearColor].CGColor;
        
        
        _layer2 = [CAShapeLayer layer];
        _layer2.frame = _bottomLabel.bounds;
        _layer2.path = path.CGPath;
        //        _layer2.backgroundColor = [UIColor blackColor].CGColor;
        _layer2.strokeColor = [UIColor clearColor].CGColor;
        
        _topLabel.layer.mask = _layer;
        _bottomLabel.layer.mask = _layer2;
        
        
        _waveNum = 3;
        _waveWidth = w + 0.5;
        _waveHeight = 3;
        _h = style == ProgressStyle ? w : w/2;
        self.title = style == ProgressStyle ? @"%0.0" : @"";
        _speed = 6.f;
        
    }
    return self;
}

- (void)starWave
{
    _link = [CADisplayLink displayLinkWithTarget:self selector:@selector(doAni)];
    [_link addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
}


- (void)stopWave
{
    [_link invalidate];
    _link = nil;
}

- (void)setTitle:(NSString *)title{
    
    _crossLabel.text = title;
    _bottomLabel.text = title;
    _topLabel.text = title;
    _title = title;
}

- (void)changeProgressValue:(CGFloat)value{
    
    _h = _waveWidth * (1 - value);
    self.title = [NSString stringWithFormat:@"%.1f%%",value * 100];
}

- (void)doAni
{
    _offset += _speed;
    
    //设置第一条波曲线的路径
    CGMutablePathRef pathRef = CGPathCreateMutable();
    //起始点
    CGFloat startY = _waveHeight*sinf(_offset*M_PI/_waveWidth) + _h;
    CGPathMoveToPoint(pathRef, NULL, 0, startY);
    //第一个波的公式
    for (CGFloat i = 0.0; i < _waveWidth; i ++) {
        CGFloat y = 1.1*_waveHeight*sinf(_waveNum*M_PI*i/_waveWidth + _offset*M_PI/_waveWidth) + _h;
        CGPathAddLineToPoint(pathRef, NULL, i, y);
    }
    CGPathAddLineToPoint(pathRef, NULL, _waveWidth, 0);
    CGPathAddLineToPoint(pathRef, NULL, 0, 0);
    CGPathCloseSubpath(pathRef);
    //设置第一个波layer的path
    _layer.path = pathRef;
    _layer.fillColor = [UIColor lightGrayColor].CGColor;
    CGPathRelease(pathRef);
    
    //设置第二条波曲线的路径
    CGMutablePathRef pathRef2 = CGPathCreateMutable();
    CGFloat startY2 = _waveHeight*sinf(_offset*M_PI/_waveWidth + M_PI/3)+_h;
    CGPathMoveToPoint(pathRef2, NULL, 0, startY2);
    //第二个波曲线的公式
    for (CGFloat i = 0.0; i < _waveWidth; i ++) {
        CGFloat y = 1.1 *_waveHeight*sinf(_waveNum*M_PI*i/_waveWidth + _offset*M_PI/_waveWidth + M_PI/3) + _h;
        CGPathAddLineToPoint(pathRef2, NULL, i, y);
    }
    
    CGPathAddLineToPoint(pathRef2, NULL, _waveWidth, _bottomLabel.frame.size.height);
    CGPathAddLineToPoint(pathRef2, NULL, 0, _bottomLabel.frame.size.height);
    CGPathCloseSubpath(pathRef2);
    
    _layer2.path = pathRef2;
    _layer2.fillColor = [UIColor blackColor].CGColor;
    CGPathRelease(pathRef2);
}

- (void)dealloc{
    [_link invalidate];
    _link = nil;
}


@end

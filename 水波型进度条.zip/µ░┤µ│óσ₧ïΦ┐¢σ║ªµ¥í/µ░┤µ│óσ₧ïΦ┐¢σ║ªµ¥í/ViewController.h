//
//  ViewController.h
//  水波型进度条
//
//  Created by 王双龙 on 16/10/7.
//  Copyright © 2016年 http://www.jianshu.com/users/e15d1f644bea All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) UILabel *crossLabel;
@property (strong, nonatomic) UILabel *topLabel;
@property (strong, nonatomic) UILabel *bottomLabel;
@property (assign, nonatomic) CGFloat speed;
@property (assign, nonatomic) CGFloat waveHeight;
@property (assign, nonatomic) CGFloat waveNum;


@end


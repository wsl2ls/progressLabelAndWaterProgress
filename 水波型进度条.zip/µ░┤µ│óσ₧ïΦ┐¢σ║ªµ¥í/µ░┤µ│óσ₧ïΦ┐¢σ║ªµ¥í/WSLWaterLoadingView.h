//
//  WSLWaterLoadingView.h
//  水波型进度条
//
//  Created by 王双龙 on 16/10/7.
//  Copyright © 2016年 http://www.jianshu.com/users/e15d1f644bea All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    ProgressStyle, //有进度时
    LoadingStyle  // 无进度时
} ViewStyle;

@interface WSLWaterLoadingView : UIView

@property (strong, nonatomic) UILabel *crossLabel;
@property (strong, nonatomic) UILabel *topLabel;
@property (strong, nonatomic) UILabel *bottomLabel;
//速率，默认6；
@property (assign, nonatomic) CGFloat speed;
//浪个数，默认3；
@property (assign, nonatomic) CGFloat waveNum;
//浪的高度,默认3；
@property (assign, nonatomic) CGFloat waveHeight;

@property (copy, nonatomic) NSString * title;

- (instancetype)initWithFrame:(CGRect)frame font:(UIFont *)titleFont viewStyle:(ViewStyle)style;

- (void)stopWave;

- (void)starWave;

//value是百分比
- (void)changeProgressValue:(CGFloat)value;

@end

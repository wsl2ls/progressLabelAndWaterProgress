//
//  ViewController.m
//  水波型进度条
//
//  Created by 王双龙 on 16/10/7.
//  Copyright © 2016年 http://www.jianshu.com/users/e15d1f644bea All rights reserved.
//

#import "ViewController.h"
#import "WSLWaterLoadingView.h"


@interface ViewController ()
{
    WSLWaterLoadingView * _progressView;
    WSLWaterLoadingView * _loadingView;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    WSLWaterLoadingView * progressView = [[WSLWaterLoadingView alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width/2 - 50, 64, 100, 100) font:[UIFont systemFontOfSize:20] viewStyle:ProgressStyle];
    progressView.speed = 6;
    [self.view addSubview:progressView];
    [progressView starWave];
    _progressView = progressView;
    
    
    WSLWaterLoadingView * loadingView = [[WSLWaterLoadingView alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width/2 - 50, 64 + 140, 100, 100) font:[UIFont systemFontOfSize:20] viewStyle:LoadingStyle];
    loadingView.speed = 6;
    loadingView.waveHeight = 6;
    loadingView.title = @"加载中...😀";
    [self.view addSubview:loadingView];
    [loadingView starWave];
    _loadingView = loadingView;

    
    UISlider * slider = [[UISlider alloc] initWithFrame:CGRectMake(_progressView.frame.origin.x - 50, _progressView.frame.origin.y + 120, 200, 5)];
    [self.view addSubview:slider];
    [slider addTarget:self action:@selector(changValue:) forControlEvents:UIControlEventValueChanged];
}

- (void)changValue:( UISlider *)slider{
    
     [_progressView changeProgressValue:slider.value];
    
    if (slider.value == 1) {
        _loadingView.title = @"加载完成";
    }else{
        _loadingView.title = @"加载中...😀";
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

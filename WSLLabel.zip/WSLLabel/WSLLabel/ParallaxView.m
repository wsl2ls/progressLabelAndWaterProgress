//
//  ParallaxView.m
//  WSLLabel
//
//  Created by 王双龙 on 16/10/8.
//  Copyright © 2016年 http://www.jianshu.com/users/e15d1f644bea All rights reserved.
//

#import "ParallaxView.h"

#define ScreenWidth  [UIScreen mainScreen].bounds.size.width
#define ScreenHeight [UIScreen mainScreen].bounds.size.height

@interface ParallaxView ()

//顶层View
@property(nonatomic,strong) UIImageView * showView;
//中间层View
@property (nonatomic,strong) UIView * clipView;

@end

@implementation ParallaxView

- (instancetype)initWithFrame:(CGRect)frame withClipFrame:(CGRect)clipFrame ImageName:(NSString *)name
{
    if (self = [super initWithFrame:frame])
    {
        self.backgroundColor = [UIColor clearColor];
        
        CGSize size = frame.size;
        
        //滑块
        _clipView = [[UIView alloc]initWithFrame:clipFrame];
        _clipView.backgroundColor = [UIColor whiteColor];
        //设置不显示超出的部分
        _clipView.clipsToBounds = YES;
        _clipView.userInteractionEnabled = YES;
        [self addSubview:_clipView];
        
        //显示
        _showView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        _showView.image = [UIImage imageNamed:name];
        [_clipView addSubview:_showView];
        
        //添加拖动手势
        UIPanGestureRecognizer * pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panView:)];
        [_clipView addGestureRecognizer:pan];
    }
    return self;
}


- (instancetype)initWithFrame:(CGRect)frame withClipFrame:(CGRect)clipFrame MagnifyingGlassWithImageName:(NSString *)name
{
    if (self = [super init])
    {
        self.backgroundColor = [UIColor clearColor];
        
        CGSize size = frame.size;
        
        //滑块
        _clipView = [[UIView alloc]initWithFrame:clipFrame];
        _clipView.backgroundColor = [UIColor whiteColor];
        _clipView.layer.cornerRadius = 50;
        _clipView.layer.masksToBounds = YES;
        //设置不显示超出的部分
        _clipView.clipsToBounds = YES;
        _clipView.userInteractionEnabled = YES;
        [self addSubview:_clipView];
        
        //显示
        _showView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        _showView.image = [UIImage imageNamed:name];
        
        [_clipView addSubview:_showView];
        
        //添加拖动手势
        UIPanGestureRecognizer * pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panView:)];
        [_clipView addGestureRecognizer:pan];
    }
    return self;
}

- (void)panView:(UIPanGestureRecognizer *)sender
{
    CGPoint pt = [sender translationInView:self];
    
    CGPoint clipCenter = _clipView.center;
    CGPoint showCenter = _showView.center;
    
    clipCenter.x += pt.x;
    clipCenter.y += pt.y;
    showCenter.x -= pt.x; //退行
    showCenter.y -= pt.y;
    
    _clipView.center = clipCenter;
    _showView.center = showCenter;
    
    [sender setTranslation:CGPointZero inView:self];
}


@end

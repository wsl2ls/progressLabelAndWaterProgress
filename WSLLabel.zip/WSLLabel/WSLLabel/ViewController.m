//
//  ViewController.m
//  WSLLabel
//
//  Created by 王双龙 on 16/10/8.
//  Copyright © 2016年 http://www.jianshu.com/users/e15d1f644bea All rights reserved.
//

#import "ViewController.h"
#import "ProgressLabel.h"
#import "HollowLabel.h"
#import "ParallaxView.h"

@interface ViewController ()
{
    ProgressLabel * _progressLabel;
    ProgressLabel * _progressLabel2;
    UILabel * label;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSTimer * timer3 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(progressChange) userInfo:nil repeats:YES];
    
    //  1.进度字体
    [self createProgressLabel];
    
    //  2.镂空字体
    [self createHollowPutLabel];
    
    //  3.视觉差
    [self createParallaxView];
}

#pragma mark -- Help Methods

- (void)createProgressLabel{
    
    _progressLabel = [[ProgressLabel alloc] initWithFrame:CGRectMake(0, 0, 300, 50) LabelStyle:FlashStyle];
    _progressLabel.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2, 50 + 64);
    _progressLabel.backgroundColor = [UIColor blackColor];
    _progressLabel.backgroundTextColor = [UIColor whiteColor];
    _progressLabel.foregroundTextColor = [UIColor greenColor];
    _progressLabel.spaceWidth = 20;
    _progressLabel.text = @"https://github.com/wslcmk";
    _progressLabel.textAlignment = NSTextAlignmentCenter;
    _progressLabel.font = [UIFont systemFontOfSize:20];
    //_progressLabel.clipWidth = _progressLabel.frame.size.width/3;
    _progressLabel.dispProgress = 0.33;
    [self.view addSubview:_progressLabel];
    
    
    _progressLabel2 = [[ProgressLabel alloc] initWithFrame:CGRectMake(0, 0, 300, 50) LabelStyle:ProgressStyle];
    _progressLabel2.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2, 50 + 64 + 70);
    _progressLabel2.backgroundColor = [UIColor blackColor];
    _progressLabel2.backgroundTextColor = [UIColor whiteColor];
    _progressLabel2.foregroundTextColor = [UIColor greenColor];
    _progressLabel2.text = @"https://github.com/wslcmk";
    _progressLabel2.textAlignment = NSTextAlignmentCenter;
    _progressLabel2.font = [UIFont systemFontOfSize:20];
    //_progressLabel.clipWidth = _progressLabel.frame.size.width/3;
    _progressLabel2.dispProgress = 0.33;
    [self.view addSubview:_progressLabel2];
    
}
- (void)createHollowPutLabel{
   
    UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 300, 50)];
    imageView.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2, 50 + 64 + 70 + 70);
    imageView.image = [UIImage imageNamed:@"wang.jpeg"];
    [self.view addSubview:imageView];
    
    
   HollowLabel * _hollowOutLabel = [[HollowLabel alloc] initWithFrame:CGRectMake(0, 0, 300, 50)];
   //_hollowOutLabel.center = CGPointMake([UIScreen mainScreen].bounds.size.width / 2, 50 + 64 + 70);
    _hollowOutLabel.text = @"https://github.com/wslcmk";
    _hollowOutLabel.textColor = [UIColor blueColor];
    _hollowOutLabel.backgroundColor = [UIColor blackColor];
    //    _hollowOutLabel.alpha = 0.7;
    _hollowOutLabel.font = [UIFont boldSystemFontOfSize:40];
    _hollowOutLabel.textAlignment = NSTextAlignmentCenter;
    [imageView addSubview:_hollowOutLabel];

    
}

- (void)createParallaxView{
    
    UIImageView * imageView = [[UIImageView alloc] initWithFrame:CGRectMake(50, 300, 200, 200) ];
    imageView.image = [UIImage imageNamed:@"haha"];
    [self.view addSubview:imageView];
    
    
    ParallaxView * paraView = [[ParallaxView alloc] initWithFrame:CGRectMake(50, 300, 200, 200) withClipFrame: CGRectMake(0, 0, 50, 50) ImageName:@"wang.jpeg"];
    
    [self.view addSubview:paraView];
   // [self.view sendSubviewToBack:paraView];
}

#pragma mark -- Event Helps
- (void)progressChange{
    
    _progressLabel.dispProgress += 0.04;
    _progressLabel2.dispProgress += 0.04;
    [_progressLabel changProgressValue:_progressLabel.dispProgress];
    [_progressLabel2 changProgressValue:_progressLabel2.dispProgress];
    if (_progressLabel.dispProgress >= 1) {
        _progressLabel.dispProgress = 0;
        _progressLabel2.dispProgress = 0;
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

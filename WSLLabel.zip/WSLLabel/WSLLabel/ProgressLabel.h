//
//  ProgressLabel.h
//  WSLLabel
//
//  Created by 王双龙 on 16/10/8.
//  Copyright © 2016年 http://www.jianshu.com/users/e15d1f644bea. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    ProgressStyle, //有进度
    FlashStyle  //闪一闪
} LabelStyle;

@interface ProgressLabel : UIView

@property (nonatomic, assign) CGFloat  dispProgress;          //显示进度(0,1)

@property (nonatomic, strong) UIColor  * foregroundTextColor; //前景label字体颜色
@property (nonatomic, strong) UIColor  * backgroundTextColor; //背景label字体颜色

@property (nonatomic, copy  ) NSString * text;                //label内容
@property (nonatomic, strong) UIFont   * font;                //label字体
@property (nonatomic, assign) NSTextAlignment textAlignment;  //label对齐模式

@property (nonatomic,assign) LabelStyle style;//Label样式
@property (assign, nonatomic) CGFloat spaceWidth;//闪一闪 模式下的间距

- (instancetype)initWithFrame:(CGRect)frame LabelStyle:(LabelStyle)style;

//改变进度
- (void)changProgressValue:(CGFloat)value;

@end
